package com.YumCart.request;

import lombok.Data;

@Data
public class IngredientsCategoryRequest {

	private String name;
	private Long restaurantId;
	private Long categoryId;
}
