package com.YumCart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.YumCart.dto.RestaurantDto;
import com.YumCart.model.Restaurant;
import com.YumCart.model.User;
import com.YumCart.service.RestaurantService;
import com.YumCart.service.UserService;

@RestController
@RequestMapping("/api/restaurants")
public class RestaurantController {

	
	@Autowired
	private RestaurantService restService;
	@Autowired
	private UserService userService;
	
	
	@GetMapping("/search")
	public ResponseEntity<List<Restaurant>>searchRestaurant(
			@RequestHeader("Authorization") String jwt,
			@RequestParam String keyword) throws Exception{
		User user=userService.findUserByJwtToken(jwt);
		List<Restaurant> restaurant=restService.searchRestaurant(keyword);
		return new ResponseEntity<>(restaurant, HttpStatus.OK);
	}
	
	@GetMapping("")
	public ResponseEntity<List<Restaurant>>getAllRestaurant(
			@RequestHeader("Authorization") String jwt) throws Exception{
		User user=userService.findUserByJwtToken(jwt);
		List<Restaurant> restaurant=restService.getAllRestaurant();
		return new ResponseEntity<>(restaurant, HttpStatus.OK);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Restaurant>findRestaurantById(
			@RequestHeader("Authorization") String jwt,
			@PathVariable Long id) throws Exception{
		User user=userService.findUserByJwtToken(jwt);
		Restaurant restaurant=restService.findRestaurantById(id);
		return new ResponseEntity<>(restaurant, HttpStatus.OK);
	}
	
	@PutMapping("/{id}/add-favourites")
	public ResponseEntity<RestaurantDto>addToFavourites(
			@RequestHeader("Authorization") String jwt,
			@PathVariable Long id) throws Exception{
		User user=userService.findUserByJwtToken(jwt);
		RestaurantDto restaurant=restService.addToFavourites(id, user);
		
		return new ResponseEntity<>(restaurant, HttpStatus.OK);
	}
}
