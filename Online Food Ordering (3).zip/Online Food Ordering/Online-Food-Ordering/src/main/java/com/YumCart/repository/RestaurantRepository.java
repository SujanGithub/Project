package com.YumCart.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.YumCart.model.Restaurant;

public interface RestaurantRepository extends JpaRepository<Restaurant, Long> {

	@Query("select r from Restaurant r where lower(r.name) like lower(concat('%',:query,'%'))"
			+ 
		" or lower(r.cuisineType) like lower(concat('%',:query,'%'))")
	List<Restaurant> findBySearchQuery(String query);
////	
//	@Query("SELECT r FROM Restaurant r WHERE r.name LIKE %:query% OR r.cusineType LIKE %:query%")
//	List<Restaurant> findBySearchQuery(@Param("query") String query);

	
	Restaurant findByOwnerId(Long userId);
	
	
}
