package com.YumCart.model;

import lombok.Data;


@Data
public class ContactInformation {
	
	private String mobile;
	
	private String email;
//	
//	private String twitter;
//	private String instagram;
	

}
