package com.YumCart.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.YumCart.dto.RestaurantDto;
import com.YumCart.model.Restaurant;
import com.YumCart.model.User;
import com.YumCart.repository.AddressRepository;
import com.YumCart.repository.RestaurantRepository;
import com.YumCart.repository.UserRepository;
import com.YumCart.request.CreateRestaurantRequest;

@Service
public class RestaurantService {
	
	@Autowired
	private RestaurantRepository restaurantRepository;
	
	@Autowired
	private AddressRepository addressRepository;

	@Autowired
	private UserRepository userRepository;
	

	public Restaurant createRestaurant(CreateRestaurantRequest req, User user) {
		Restaurant restaurant = new Restaurant(); 
		restaurant.setAddress(req.getAddress());
		restaurant.setContactInformation(req.getContactInformation());
		restaurant.setCuisineType(req.getCuisineType());
		restaurant.setDescription(req.getDescription());
		restaurant.setImages(req.getImages());
		restaurant.setName(req.getName());
		restaurant.setOpeningHours(req.getOpeningHours());
		restaurant.setRegistrationDate(LocalDateTime.now());
		restaurant.setOwner(user);
		return restaurantRepository.save(restaurant);
	}
	//createRestaurantrequest created because the fields will be same for create and update restaurant
public Restaurant updateRestaurant(Long restaurantId, CreateRestaurantRequest updatedRestaurant) throws Exception{
		Restaurant rest=findRestaurantById(restaurantId);
		if(rest.getCuisineType()!=null) {
			rest.setCuisineType(updatedRestaurant.getCuisineType());
		}
		if(rest.getDescription()!=null) {
			rest.setDescription(updatedRestaurant.getDescription());
		}
		if(rest.getName()!=null) {
			rest.setName(updatedRestaurant.getName());;
		}
		return restaurantRepository.save(rest);
	}

public void deleteRestaurant(Long restaurantId) throws Exception{
	 restaurantRepository.deleteById(restaurantId);
	 return;
}

public List<Restaurant> getAllRestaurant(){
	return restaurantRepository.findAll();
	}

public List<Restaurant> searchRestaurant(String keyword)
{
return restaurantRepository.findBySearchQuery(keyword);
}
public Restaurant findRestaurantById(Long id) throws Exception{
	Optional<Restaurant> opt=restaurantRepository.findById(id);
	if(opt.isEmpty()) {
		throw new Exception("restaurant not found with Id: "+id);
	}
	return opt.get();
	}

public Restaurant getRestaurantByUserId(Long userId) throws Exception{
	Restaurant restaurant=restaurantRepository.findByOwnerId(userId);
	if(restaurant==null)
	{
		throw new Exception("Restaurant not found with owner Id: "+userId);
	}
	return restaurant;
}

public RestaurantDto addToFavourites(Long restaurantId, User user) throws Exception{
	Restaurant rest=findRestaurantById(restaurantId);
	RestaurantDto dto = new RestaurantDto();
	dto.setDescription(rest.getDescription());
	dto.setImages(rest.getImages());
	dto.setTitle(rest.getName());
	dto.setId(restaurantId);
	boolean isFavourite= false;
	List<RestaurantDto> favourites= user.getFavourites();
	for(RestaurantDto favourite: favourites) {
		if(favourite.getId().equals(restaurantId)) {
			isFavourite=true;
			break;
		}
	}
	
	if(isFavourite) {
		favourites.removeIf(favourite->favourite.getId().equals(restaurantId));
		
	}else {
		favourites.add(dto);
	}
	
	userRepository.save(user);
	return dto;
}

public Restaurant updateRestaurantStatus(Long id)throws Exception{
	Restaurant rest=findRestaurantById(id);
	rest.setOpen(!rest.isOpen());
	return restaurantRepository.save(rest);
}

}
