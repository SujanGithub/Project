package com.YumCart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.YumCart.model.Address;
import com.YumCart.model.Cart;
import com.YumCart.model.CartItem;
import com.YumCart.model.Order;
import com.YumCart.model.OrderItem;
import com.YumCart.model.Restaurant;
import com.YumCart.model.User;
import com.YumCart.repository.AddressRepository;
import com.YumCart.repository.OrderItemRepository;
import com.YumCart.repository.OrderRepository;
import com.YumCart.repository.RestaurantRepository;
import com.YumCart.repository.UserRepository;
import com.YumCart.request.OrderRequest;
import java.util.Date;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private OrderItemRepository orderItemRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private AddressRepository addressRepo;
	
	@Autowired
	private RestaurantService restService;
	
	@Autowired
	private CartService cartService;
	
	public Order createOrder(OrderRequest order, User user) throws Exception {
		Address shipAddress=order.getDeliveryAddress();
		Address savedAddress=addressRepo.save(shipAddress);
		
		if(!user.getAddresses().contains(savedAddress))
		{
			user.getAddresses().add(savedAddress);
			userRepository.save(user);
		}
		
		Restaurant rest=restService.findRestaurantById(order.getRestaurantId());
		Order createdOrder = new Order();
		createdOrder.setCustomer(user);
		createdOrder.setCreatedAt(new Date());
		createdOrder.setOrderStatus("PENDING");
		createdOrder.setDeliveryAddress(savedAddress);
		createdOrder.setRestaurant(rest);
		
		
		Cart cart=cartService.findCartByUserId(user.getId());
		
		List<OrderItem> orderItems=new ArrayList<>();
		
		for(CartItem c:cart.getItem()) {
			OrderItem orderItem= new OrderItem();
			orderItem.setFood(c.getFood());
			orderItem.setIngredients(c.getIngredients());
			orderItem.setQuantity(c.getQuantity());
			
			orderItem.setTotalPrice(c.getTotalPrice());
			
			OrderItem savedOrderItem=orderItemRepository.save(orderItem);
			orderItems.add(savedOrderItem);
		}
		
		Long totalPrice=cartService.calculateCartTotals(cart);
		createdOrder.setItems(orderItems);
		createdOrder.setTotalPrice(totalPrice);
		
		
		Order savedOrder= orderRepository.save(createdOrder);
		rest.getOrders().add(savedOrder);
		
		return createdOrder;
		
	}
	
	public Order updateOrder(Long orderId, String orderStatus) throws Exception{
		Order order=findOrderById(orderId);
		if(orderStatus.equals("OUT FOR DELIVERY")|| orderStatus.equals("DELIVERED")
				|| orderStatus.equals("COMPLETED")
				|| orderStatus.equals("PENDING")) {
			order.setOrderStatus(orderStatus);
			return orderRepository.save(order);
		}
		throw new Exception("Please select a valid order Status");
	}
	
	
	public void cancelOrder(Long orderId) throws Exception{
		Order order=findOrderById(orderId);
		orderRepository.deleteById(orderId);
	}
	
	public List<Order> getUsersOrder(Long userId) throws Exception{
		return orderRepository.findByCustomerId(userId);
	}
	
	public List<Order> getRestaurantOrders(Long restaurantId, String orderStatus) 
			throws Exception{
		List<Order> orders=orderRepository.findByRestaurantId(restaurantId);
		
		if(orderStatus!=null){
			orders=orders.stream().filter(order->
			order.getOrderStatus().equals(orderStatus)).collect(Collectors.toList());
		}
		return orders;
	}
	
	public Order findOrderById(Long orderId)throws Exception{
		Optional<Order>optionalOrder=orderRepository.findById(orderId);
		if(optionalOrder.isEmpty()) {
			throw new Exception("Order does not exist with id: "+orderId);
		}
		return optionalOrder.get();	}

}
