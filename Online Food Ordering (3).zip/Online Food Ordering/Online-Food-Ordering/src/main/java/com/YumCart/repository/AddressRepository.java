package com.YumCart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.YumCart.model.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {

}
