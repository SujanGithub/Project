package com.YumCart.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.YumCart.model.Cart;
import com.YumCart.model.CartItem;
import com.YumCart.model.Food;
import com.YumCart.model.User;
import com.YumCart.repository.CartItemRepository;
import com.YumCart.repository.CartRepository;
import com.YumCart.request.AddCartItemRequest;

@Service
public class CartService {

	@Autowired
	private CartRepository cartRepository;
	@Autowired
	private UserService userService;
	
	@Autowired
	private CartItemRepository cartItemRepository;
	
	@Autowired 
	private FoodService foodService;
	
	public CartItem addItemToCart(AddCartItemRequest req, 
			String jwt) throws Exception{
		
		User user=userService.findUserByJwtToken(jwt);
		
		Food food=foodService.findFoodById(req.getFoodId());
		Cart cart=cartRepository.findByCustomerId(user.getId());
		
		for(CartItem c:cart.getItem()) {
			if(c.getFood().equals(food)) {
				int newQuantity=c.getQuantity()+req.getQuantity();
				return updateCartItemQuantity(c.getId(), newQuantity);
			}
		}
		
		CartItem newCartItem= new CartItem();
		newCartItem.setFood(food);
		newCartItem.setCart(cart);
		newCartItem.setQuantity(req.getQuantity());
		newCartItem.setIngredients(req.getIngredients());
		newCartItem.setTotalPrice(req.getQuantity()*food.getPrice());
		
		CartItem saved=cartItemRepository.save(newCartItem);
		cart.getItem().add(saved);
		return saved;
	}
	
	public CartItem updateCartItemQuantity(Long cartItemId, int quantity)
			throws Exception{
		Optional<CartItem> cartItem=cartItemRepository.findById(cartItemId);
		if(cartItem.isEmpty()) {
			throw new Exception("cart item not found");
		}
		CartItem item=cartItem.get();
		item.setQuantity(quantity);
		item.setTotalPrice(item.getFood().getPrice()*quantity);
		
	return cartItemRepository.save(item);
	}
	
	public Cart removeItemFromCart(Long cartItemId, String jwt) 
			throws Exception{
		
		User user=userService.findUserByJwtToken(jwt);
		
		Cart cart=cartRepository.findByCustomerId(user.getId());
		
		Optional<CartItem> cartItem=cartItemRepository.findById(cartItemId);
		if(cartItem.isEmpty()) {
			throw new Exception("cart item not found");
		}
		CartItem item=cartItem.get();
		cart.getItem().remove(item);
		
		return cartRepository.save(cart);
	}
	
	public Long calculateCartTotals(Cart cart)throws Exception{
		Long total=0L;
		for(CartItem cartItem: cart.getItem()) {
			total+=cartItem.getFood().getPrice()*cartItem.getQuantity();
			
		}
		return total;
		
	}
	
	public Cart findCartById(Long id)throws Exception{
		Optional<Cart> optionalCart=cartRepository.findById(id);
		if(optionalCart.isEmpty()) {
			throw new Exception("cart not found with id "+id);
		}
		return optionalCart.get();
		}
	

	public Cart findCartByUserId(Long userId)throws Exception{
//		User user=userService.findUserByJwtToken(jwt);
		Cart cart=cartRepository.findByCustomerId(userId);
		cart.setTotal(calculateCartTotals(cart));
		return cart;
	}
	
	public Cart clearCart(Long userId) throws Exception{
//		User user=userService.findUserByJwtToken(jwt);
		Cart cart=findCartByUserId(userId);
		cart.getItem().clear();
		return cartRepository.save(cart);
	}
}
