package com.YumCart.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.YumCart.model.IngredientsCategory;
import com.YumCart.model.IngredientsItem;
import com.YumCart.model.Restaurant;
import com.YumCart.repository.IngredientsCategoryRepository;
import com.YumCart.repository.IngredientsItemRepository;

@Service
public class IngredientsService {
	@Autowired
	private IngredientsCategoryRepository ingCatRepo;
	
	@Autowired
	private IngredientsItemRepository ingItemRepo;
	
	@Autowired
	private RestaurantService restService;
	
	
	
	public IngredientsCategory  createIngredientCategory(String name, Long restaurantId) throws Exception
	{
		Restaurant rest=restService.findRestaurantById(restaurantId);
		IngredientsCategory category=new IngredientsCategory();
		category.setRestaurant(rest);
		category.setName(name);
		return ingCatRepo.save(category);
	}
	
	public IngredientsCategory findIngredientCategoryById(Long id)throws Exception
	{
		Optional<IngredientsCategory> opt=ingCatRepo.findById(id);
		if(opt.isEmpty())
		{
			throw new Exception("Ingredient Category not found");
		}
		return opt.get();
	}
	
	public List<IngredientsCategory> findIngredientCategoryByRestaurantId(Long id) throws Exception
	{
		restService.findRestaurantById(id);
		return ingCatRepo.findRestaurantById(id);
	}
	
	public IngredientsItem createIngredientItem(Long restaurantId, 
			String ingredientName, Long categoryId)throws Exception
	{
		Restaurant restaurant=restService.findRestaurantById(restaurantId);
		IngredientsCategory category= findIngredientCategoryById(categoryId);
		IngredientsItem item= new IngredientsItem();
		
		item.setName(ingredientName);
		item.setRestaurant(restaurant);
		item.setCategory(category);
		
		IngredientsItem ing=ingItemRepo.save(item);
		category.getIngredients().add(ing);
		return ing;
		
	}
	
	public List<IngredientsItem> findRestaurantIngredients(Long restaurantId)
	{
		return ingItemRepo.findByRestaurantId(restaurantId);
	}
	
	public IngredientsItem updateStock(Long id) throws Exception
	{
		Optional<IngredientsItem> optionalIngredientItem=ingItemRepo.findById(id);
		if(optionalIngredientItem.isEmpty()) {
			throw new Exception("Ingredient not found");
		}
		IngredientsItem ingItem=optionalIngredientItem.get();
		ingItem.setInStock(!ingItem.isInStock());
		return ingItemRepo.save(ingItem);
	}
	
	
	
}
