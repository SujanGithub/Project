package com.YumCart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.YumCart.model.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long>{

}
