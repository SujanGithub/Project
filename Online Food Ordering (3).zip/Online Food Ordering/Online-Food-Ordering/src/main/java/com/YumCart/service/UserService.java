package com.YumCart.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.YumCart.config.JwtProvider;
import com.YumCart.model.User;
import com.YumCart.repository.UserRepository;
@Service
public class UserService {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private JwtProvider jwtProvider;
	public User findUserByJwtToken(String jwt) throws Exception
	{
		String email=jwtProvider.getEmailFromJwtToken(jwt);
		User user=userRepository.findByEmail(email);
		if(user==null) {
			throw new Exception("user not found");
		}
		return user;
	}
	public User findUserByEmail(String email) throws Exception{
		User user=userRepository.findByEmail(email);
		if(user==null) {
			throw new Exception("user not found");
		}
		return user;
	}

}
