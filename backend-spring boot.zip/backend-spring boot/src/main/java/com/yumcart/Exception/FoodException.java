package com.yumcart.Exception;

public class FoodException extends Exception {

	public FoodException(String message) {
		super(message);

	}

}
