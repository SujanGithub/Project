package com.yumcart.Exception;

public class OrderException extends Exception {

	public OrderException(String message) {
		super(message);
		
	}
	

}
