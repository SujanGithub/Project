package com.yumcart.service;

import com.yumcart.model.OrderItem;

public interface OrderItemService {
	
	public OrderItem createOrderIem (OrderItem orderItem);

}
