package com.yumcart.service;

import com.yumcart.model.CartItem;

public interface CartItemService {
	
	public CartItem createCartItem(CartItem item);

}
